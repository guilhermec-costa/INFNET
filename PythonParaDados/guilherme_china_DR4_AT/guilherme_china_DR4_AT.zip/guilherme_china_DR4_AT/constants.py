DB_FILE = "mercado-at.db"
CSV_PRODUTOS = "./data/produtos.csv"
CSV_CLIENTES = "./data/clientes.csv"