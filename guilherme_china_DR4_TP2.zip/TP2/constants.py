CAMINHO_NOMES = 'nomes.txt'
CAMINHO_JSON = 'produtos.json'
CAMINHO_CSV = 'produtos.csv'
