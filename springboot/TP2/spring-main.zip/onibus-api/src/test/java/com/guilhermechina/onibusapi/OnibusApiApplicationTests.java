package com.guilhermechina.onibusapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnibusApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
