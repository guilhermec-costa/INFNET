/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(tabs)` | `/(tabs)/` | `/(tabs)/ForgetPassword` | `/(tabs)/NewItem` | `/(tabs)/dashboard` | `/(tabs)/explore` | `/(tabs)/home` | `/(tabs)/login` | `/(tabs)/register` | `/(tabs)/settings` | `/ForgetPassword` | `/NewItem` | `/_sitemap` | `/dashboard` | `/explore` | `/home` | `/login` | `/register` | `/settings`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
