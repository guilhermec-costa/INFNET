export default function Register()
{
    return (
        <div>Register</div>
    );
}