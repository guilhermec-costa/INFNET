IBGE_URL = "https://ftp.ibge.gov.br/Acesso_a_internet_e_posse_celular/2015/Tabelas_de_Resultados/indice_de_tabelas.txt"
CHROMEDRIVER_PATH = "/usr/bin/chromedriver"  
# Opa professor, beleza? Talvez tu só tenha que ajustar o link do driver do chromium aqui.
# baixei pelo pacman aqui no linux.
DB_PATH = "scraping_data.db"
BBC_URL = "https://www.bbc.com/portuguese"