import psycopg2

def conectar_banco():
    try:
        conn = psycopg2.connect(
            host="localhost",    
            dbname="empresa",    
            user="postgres",  
            password="postgres",
            port=5432
        )
        return conn
    except Exception as e:
        print(f"Erro ao conectar com o banco de dados: {e}")
        return None

def calcular_inss(salario_base):
    faixas_inss = [
        (1412.00, 0.075),   
        (2666.68, 0.09),    
        (4000.03, 0.12),    
        (float('inf'), 0.14) 
    ]
    
    inss = 0
    faixa_inicial = 0
    
    for limite, percentual in faixas_inss:
        if salario_base > faixa_inicial:
            faixa_valor = min(salario_base, limite) - faixa_inicial
            inss += faixa_valor * percentual
            faixa_inicial = limite
        else:
            break
    return inss

def calcular_IR(salario_com_inss):
    faixas_ir = [
        (2112.00, 0.00, 0),          
        (2826.65, 0.075, 158.40),     
        (3751.05, 0.15, 370.40),      
        (4664.68, 0.225, 651.73),     
        (float('inf'), 0.275, 884.96) 
    ]
    
    ir = 0
    for limite, percentual, deducao in faixas_ir:
        if salario_com_inss > limite:
            ir = (salario_com_inss - limite) * percentual - deducao
            break
    return ir

def gerar_relatorio():
    conn = conectar_banco()
    if conn is None:
        return
    
    cursor = conn.cursor()
    
    cursor.execute("SELECT nome, salario_base FROM funcionarios")
    funcionarios = cursor.fetchall()

    funcionarios_relatorio = []
    
    for funcionario in funcionarios:
        nome = funcionario[0]
        salario_base = funcionario[1]
        
        inss = calcular_inss(salario_base)
        
        salario_com_inss = salario_base - inss
        ir = calcular_IR(salario_com_inss)
        salario_liquido = salario_base - inss - ir
        funcionarios_relatorio.append({
            'nome': nome,
            'salario_base': salario_base,
            'inss': inss,
            'ir': ir,
            'salario_liquido': salario_liquido
        })
    
    funcionarios_relatorio = sorted(funcionarios_relatorio, key=lambda x: x['salario_liquido'], reverse=True)
    
    for funcionario in funcionarios_relatorio:
        print(f"Nome: {funcionario['nome']}")
        print(f"Salário Base: R${funcionario['salario_base']:.2f}")
        print(f"Desconto INSS: R${funcionario['inss']:.2f}")
        print(f"Desconto IR: R${funcionario['ir']:.2f}")
        print(f"Salário Líquido: R${funcionario['salario_liquido']:.2f}")
        print('-' * 40)
    
    cursor.close()
    conn.close()

if __name__ == "__main__":
    gerar_relatorio()
