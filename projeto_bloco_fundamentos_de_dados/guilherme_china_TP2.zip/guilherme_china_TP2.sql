-----------------------------------------------------------------------------------
-- Consultas Simples

-- Listar todos os funcionários cadastrados.
select * from Funcionarios f;

-- Exibir os nomes e cargos de todos os funcionários.
select f.nome, f.cargo from Funcionarios f;

-- Encontrar os funcionários do departamento "Tecnologia".
select * from Funcionarios f
where f.departamento =  'Tecnologia';

-- Mostrar os funcionários contratados após 01/01/2023.
select * from Funcionarios f
where data_contratacao > '2023-01-01';

-- Exibir os funcionários que possuem o cargo de "Gerente".
select * from Funcionarios f
where f.cargo = 'Gerente';

-----------------------------------------------------------------------------------
-- Consultas com Filtros e Ordenação

-- Listar os 10 funcionários com os maiores salários.
select * from Funcionarios f
order by f.salario desc 
limit 10;

-- Encontrar funcionários cujo nome começa com 'Funcionario_1'.
select * from Funcionarios f
where f.nome ilike 'Funcionario_1%';

-- Listar todos os funcionários ordenados por data de contratação (mais recente primeiro).
select * from Funcionarios f
order by f.data_contratacao desc;

-- Exibir funcionários com salários entre 5000 e 7000.
select * from Funcionarios f
where f.salario between 5000 and 7000;

-- Mostrar os funcionários do departamento "Recursos Humanos" que ganham mais de 4000.
select * from Funcionarios f
where f.departamento = 'Recursos Humanos' and salario > 4000;

-----------------------------------------------------------------------------------
-- Consultas com Agregações

-- Calcular o salário médio de todos os funcionários.
select trunc(avg(f.salario), 2) media_salarial from Funcionarios f;

-- Determinar o maior e o menor salário por departamento.
select f.departamento, max(f.salario) salario_max, min(f.salario) salario_max from Funcionarios f
group by f.departamento

-- Contar quantos funcionários existem em cada cargo.
select f.cargo, count(*) nr_funcionarios from Funcionarios f
group by f.cargo

-- Exibir o total de salários pagos em cada departamento.
select f.departamento, sum(f.salario) soma_salario from Funcionarios f
group by f.departamento

-- achei a pergunta acima um pouco ambígua professor. Vou colocar outra query que interpretei como válida também,
-- apenas para desencargo de consciência
select f.departamento, count(f.salario) salarios_pagos from Funcionarios f
group by f.departamento

-- Listar o número total de funcionários na empresa.
select count(*) from Funcionarios f