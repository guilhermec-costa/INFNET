from exercicios import *

if __name__ == "__main__":
  exercicio1();
  exercicio2();
  exercicio3();
  exercicio4();
  exercicio5();
  exercicio6();
  exercicio7();
  exercicio8();
  exercicio9();
  exercicio10();
  exercicio11();
  exercicio12();
  exercicio13();
  exercicio14();
  exercicio15();
  exercicio16();
